require 'httparty'
require "rspec"
require_relative "../../features/modules/correios_httparty_bjects"