ENDERECOS = {
    valido: {
        cep: "04282-030",
        logradouro: "Rua Jaíba",
        complemento: "",
        bairro: "Vila Nair",
        localidade: "São Paulo",
        uf: "SP",
        unidade: "",
        ibge: "3550308",
        gia: "1004"
      }
}