class CorreiosHttparty
    include CorreiosHTTPartyObjects
  
    attr_reader :url_api_correios
  
    def initialize
      @url_api_correios = "https://viacep.com.br/ws/0#{cep}/json/"
      @mensagem_retorno_get_cep_invalido = "Endereço não encontrado!"
    end
  end
  